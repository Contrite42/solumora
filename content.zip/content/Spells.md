In [[Solumora]], spells are manifestations of [[Flux]] shaped through either preparation or innate mastery. Those who cast them are collectively known as [[Flux Users]], a hierarchy that ranges from common [[Flux Users|Formulists]] to rare [[Flux Users|Conduits]].

There are three forms of casting:

**[[Sigils]]**
Meticulously designed visual symbols — inscribed or drawn — that serve as precise frameworks for shaping [[Flux]]. Casting through sigils requires both the correct symbol and the caster's [[Control Tier|capacity]] to channel the required energy. Sigils are prepared in advance, stored in [[Grimoires]], or etched onto objects for repeated use. The structure of every sigil is defined entirely by [[Spell Variables]].

**[[Hand Signs]]**
Some individuals can cast spells through a series of practiced, precise hand signs. This method requires no pre-drawn [[Sigils|sigils]], relying instead on the caster's mastery of form and focused intent. Hand signs allow for quicker, more spontaneous casting but demand immense skill and years of practice. They are far rarer than sigil-based casting and pass through warrior families, military units, and personal lineages rather than formal institutions.

**[[Hypertext]]**
A linear sequence of [[Flux]] symbols developed in [[Wolfpoint]], far north of both kingdoms. Where sigils arrange variables into a fixed geometric form, Hypertext writes them as a chain of conditional logic — IF this, THEN that, WITH this output, WHILE this condition holds. It uses the same symbols as the Scholar system but as operators rather than slot-fillers, allowing for branching behavior, sequential effects, and spell logic that no current sigil shape can represent. Its [[Control Tier]] ceiling is the same as the sigil system; its expressiveness is not.

All three methods rely on the same principle: shaping [[Flux]] into a controlled form through precise structure. In both cases, only those who can channel sufficient [[Flux]] — as measured by [[Control Tier]] — can bring a spell into reality.

All documented spells are catalogued in the [[All Grimoire]], organized by rarity from [[Common Grimoire|Common]] through [[Pale Grimoire|Pale]].

*See also: [[Sigils]], [[Flux]], [[Flux Users]], [[Spell Variables]], [[All Grimoire]], [[Control Tier]]*
