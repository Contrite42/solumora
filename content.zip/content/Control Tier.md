**Control Tier** measures how much control a caster has over a spell's variables and how much [[Flux]] precision is required to execute it safely. It has two meanings at once: **Capacity / Difficulty** — how much Flux handling and precision the spell demands — and **Control Surface** — how many outer variables the sigil explicitly controls, with the rest falling back to defaults.

Control Tier is always represented by the complexity marker in the center ring (Tier 0–Tier 9), and by the Shape of the sigil (how many outer points are present).

## Tier 0–Tier 9 — Exponential Scaling

The numeric tier is the spell's **Flux handling requirement**. Each tier is roughly an order-of-magnitude jump in difficulty, capacity, stability, and precision. Every few tiers feels like a categorically different class of magic.

---

### Tier 0 — Trace

_Barely any Flux. The threshold most people never bother to formally test._

**Possible feats:** Cause a candle flame to flicker without touching it. Warm a coin slightly. Make a small sound with no clear source. Leave a faint impression on soft material.

**Misfire:** Nothing happens. Occasionally a faint unintended warmth, a brief smell, or a sound that wasn't quite right. Harmless in every case.

---

### Tier 1 — Flicker

_A small, usable trickle. The first tier where deliberate spellwork is practical._

**Possible feats:** Light a room with a stable glow sigil. Keep food warm for an hour. Deliver a deterrent shock on a locked box. Push a small object across a table. Mark a surface permanently with a faint burn.

**Misfire:** Harmless fizzles. The spell fails to hold, discharges weakly in the wrong direction, or produces a brief sensory flicker — a flash, a pop, a smell. No lasting damage to caster or environment.

---

### Tier 2 — Working

_The world average. The first tier where magic becomes genuinely useful in daily life._

**Possible feats:** Seal a container airtight. Hold a blade sharp through a full day of use. Produce a sustained flame without fuel. Send a chemical fog through a room. Detect all living heat signatures within 10 feet. Bind two surfaces together firmly enough to hold significant weight.

**Misfire:** Minor misfires. The spell activates in the wrong direction, affects an unintended nearby target, holds for a fraction of its expected duration, or produces an effect at reduced intensity. Occasionally causes minor bruising, a small burn, or brief disorientation to the caster if backlash occurs.

---

### Tier 3 — Load

_A heavy draw. Noticeably taxing for most casters. Where casual use ends and deliberate craft begins._

**Possible feats:** Erect a held barrier of force strong enough to stop a running person. Shatter a stone with focused sonic resonance. Track a specific individual's heat signature through walls. Render a liquid safe to drink by filtering its chemistry. Send a message through a linked token regardless of distance.

**Misfire:** Drift, overshoot, or spread. A targeted effect clips unintended bystanders. A barrier forms at the wrong angle or collapses inward. A chemical effect disperses too broadly. The caster may experience muscle cramps, brief disorientation, or [[Flux]] channel soreness lasting minutes to hours.

---

### Tier 4 — Strain

_[[Flux]] punishes sloppy work here. Every variable in the sigil needs to be right._

**Possible feats:** Hold a person completely immobile against their will. Sustain a wide thermal field across a room. Create a sound-dead cylinder large enough to conduct a private meeting. Read a single surface thought from a touched individual. Temporarily strip a target of their ability to cast. Steer a moving projectile in flight.

**Misfire:** Cascading hazards. A containment effect inverts and traps the caster instead. A thermal field surges and scorches the surrounding area. A neuro-disruption pulse hits everyone in range, including allies. The caster takes genuine physical harm — burns, fractured channels, bleeding from overextension. Recovery measured in days.

---

### Tier 5 — Threshold

_Most people need tools, trained anchors, or prepared sigil support to attempt this safely. The floor of [[Flux Users|Channeler]] territory._

**Possible feats:** Broadcast a neuro-disrupting field across a group simultaneously. Permanently mark someone's Soul signature for future identification. Conceal an entire group from conscious notice. Sever a single target's Flux connection temporarily. Read a target's approximate Control Tier at range.

**Misfire:** Backlash, fracture, bleed. The spell tears back through the caster's own channels. A Soul-discipline misfire may imprint a partial effect on the caster themselves. Flux bleed — uncontrolled ambient discharge — can last minutes, damaging nearby [[Sigils]] and destabilizing other active spells in the area. Caster may be incapacitated for hours. Channel damage may require weeks to fully heal.

---

### Tier 6 — Overload

_Layered stability required. A single unstable variable can cascade the entire cast._

**Possible feats:** Deliver a neuro-collapse to a single target that renders them non-functional for an hour. Permanently burn an unwilling Soul brand onto a target. Erase a target's identity from Soul-detection systems entirely. Erect a sustained field that disrupts all incoming Flux before it resolves into spells.

**Misfire:** Severe local hazard, hard abort. The spell detonates rather than fires — a thermal misfire scorches a building, a neuro misfire stuns everyone in a wide radius including the caster. Soul-discipline failures at this tier can partially imprint the intended effect on the caster permanently. The abort itself causes significant physical trauma. Caster may be unconscious for hours and functionally impaired for weeks.

---

### Tier 7 — Breakpoint

_Needs prepared sites, Flux reservoirs, or anchored support structures. Cannot be safely attempted in the middle of a field._

**Possible feats:** Strip the Flux connection from an entire group simultaneously. Permanently erase a defined period of memory from a target. Generate a sustained wide-area Flux disruption that destabilizes all active spells in a large zone. Trigger a kinetic shockwave strong enough to crack foundations and collapse weak structures.

**Misfire:** Catastrophic zone effects and messy shutdown. A failed Flux disruption field may permanently deadzone the casting area. A memory-wipe misfire may cascade into broader cognitive damage in the target — or, in severe cases, the caster. Kinetic failures at this tier are structural events. The shutdown process itself can injure anyone nearby. Caster typically survives but is nonfunctional for days to weeks and may carry permanent channel scarring.

---

### Tier 8 — Rupture

_Stability is the entire fight. The spell does not forgive any lapse in precision._

**Possible feats:** Permanently destroy a target's higher cognitive function while leaving them physically alive. Tear a target's Soul signature partially free from their physical form. Apply a kinetic force sufficient to destroy a ship hull or city gate outright. Wrap an entire area in sustained neuro-concealment that causes everyone inside to be passively ignored.

**Misfire:** Long-lived anomalies and bleed. A failed Soul-discipline cast at this tier may create a persistent local distortion in the Flux field — an area where Soul-detection behaves strangely for months. A cognitive destruction misfire may partially affect the caster's own memory or identity. Channel damage from a Tier 8 failure is typically permanent in some degree. The caster may survive, but they will not be the same.

---

### Tier 9 — Singularity

_Apex tier. [[Flux Users|Conduit]] territory. The kingdom classification system does not formally rate this._

**Possible feats:** Permanently rewrite a living person's identity, memories, and intent. Collapse the ambient Flux density of a defined area to zero — permanently. Fracture the Soul signatures of every individual in a wide field simultaneously. Alter the physical and Flux-structural properties of a site in ways that do not reverse.

**Misfire:** Structural rupture of the casting space. A failed Tier 9 cast does not simply harm the caster — it damages the local reality. Flux anomalies persist indefinitely. The area may become hostile to all future casting, or generate unpredictable effects for years. The caster, if they survive, may not be recoverable in any meaningful sense. Three of the documented [[Equatorial Desert|Zakros ruin sites]] are believed to be the result of Tier 9 failures from the civilization that predated the current kingdoms. They have not normalized in the centuries since.

---

## Population Distribution (Solumora ~250,000,000)

A person's maximum safe Control Tier is effectively **random**. It does not reliably follow bloodlines, wealth, or nationality. Training improves efficiency and stability, but rarely changes a person's ceiling.

|Max Safe Tier|Approximate Population|Share|
|---|---|---|
|Tier 0|~25,000,000|10.0%|
|Tier 1|~100,000,000|40.0%|
|Tier 2|~85,000,000|34.0%|
|Tier 3|~30,000,000|12.0%|
|Tier 4|~8,000,000|3.2%|
|Tier 5|~1,500,000|0.6%|
|Tier 6|~400,000|0.16%|
|Tier 7|~70,000|0.028%|
|Tier 8|~9,000|0.0036%|
|Tier 9|~500|0.0002%|

This keeps low-tier casting widespread while high-tier ability remains scattered and socially isolating rather than forming a stable ruling class. Those at Tier 5 and above are known as [[Flux Users|Channelers]]. Those at Tier 9 are [[Flux Users|Conduits]] — beyond what the kingdom system formally rates.

## Practical Implications

Fewer outer sigil points means faster to write and safer to distribute, but less flexible. More outer points means more configurable and adaptable, but with a higher precision and training burden. Shape controls how many variables exist; Tier controls how hard the spell is to hold safely.

## Tier Is Not Power

Control Tier measures Flux capacity and handling ceiling. It does not measure combat effectiveness, practical utility, or real-world danger. Two casters at the same tier can be categorically different in what they are capable of, for reasons the number does not capture.

**Experience** matters independently of tier. A T4 caster who has practiced a single application of their discipline for thirty years will outperform a T4 caster who learned it last month in every situation that application is relevant to. The tier describes the ceiling. It says nothing about how much of that ceiling has been explored.

**Efficiency** matters independently of tier. A caster who has refined their Flux expenditure over decades can sustain effects longer, execute them with less visible effort, and recover faster than a caster of equal or higher tier who has not done that work. In a sustained conflict, the more efficient caster wins on attrition regardless of whose ceiling is nominally higher.

**Specialization** matters independently of tier. A caster who does one thing and has done nothing else has an advantage in that one thing that a generalist of equal or higher tier may not be able to match. The generalist has breadth. The specialist has depth that the number does not reflect.

**Situational advantage** matters independently of tier. Prepared ground, familiarity with terrain, prior knowledge of an opponent's discipline, and the element of surprise are not tier effects. A T3 caster on ground they have worked for thirty years is not the same as a T3 caster in an unfamiliar location against an unknown threat.

Tier is a useful shorthand for what a caster can safely attempt. It is a poor shorthand for what a caster can actually do.

*See also: [[Flux Users]], [[Flux Expenditure]], [[Shape]], [[Sigils]], [[Spell Variables]], [[Flux]], [[Tier Assessment]]*