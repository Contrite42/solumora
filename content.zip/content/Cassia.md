_(Queen of Auralis)_

Cassia has been Queen of [[Auralis]] since she was four years old. She does not remember a time before the title. She has never been permitted to find out who she would have been without it.

She is twenty-three. She is kind, perceptive, and politically trapped in ways that have become so familiar she has stopped noticing all of them. The ones she does notice, she has chosen not to fight. This is the central fact of her life and she is quietly ashamed of it.

## Background

Cassia was elevated to the throne as an infant on the strength of bloodline and namesake — the last viable heir of a lineage that [[Auralis]] society considered too significant to let lapse. The council that placed her there has been running the kingdom in her name ever since. They are not cruel to her. They are not required to be. They provide her with every comfort, every luxury, every visible marker of a queen's life, and in exchange she signs what they ask her to sign and stands where they ask her to stand and does not press too hard on the things they do not want pressed.

She knows exactly what this arrangement is. She made her peace with it young, before she had the vocabulary to name it, and has been living inside that peace ever since.

## Character

Cassia is kinder than Auralis's culture asks its queen to be. The soft caste structure of the south — where magical ability determines social worth and low-tier casters exist in permanent shadow — sits uneasily with her. She would change it if she could. She has tried, quietly, in small ways, and learned precisely how much latitude the council allows before the comfortable life becomes noticeably less comfortable. She has not pushed past that point. She tells herself she is waiting for the right moment. She is not entirely sure she believes this.

Her [[Flux]] ability is a separate frustration. Her bloodline has produced a T7 caster at its height. Cassia is T4, undertrained, her development managed carefully by a council that understands what a fully developed queen with a T7 ceiling would mean for their continued influence. She knows enough to feel the distance between where she is and where her blood says she could be. She does not know enough to close it, and the people around her have no interest in helping her try.

## The Council

The [[Council Members]] that manage [[Auralis]] through Cassia is not unified. They share a goal — the consolidation and expansion of Auralis, pursued with the single-minded intensity of people who believe they are building toward something ultimate, a magnum opus of [[Flux]] mastery and territorial completion — but they have individual interests that create friction. Cassia has learned to read this friction carefully. It is the only political tool she has reliable access to.

She is not as passive as they believe. She is, however, as constrained as they intend.

## What She Wants

The thing Cassia wants is simple to name and difficult to execute: she wants the council's grip on [[Auralis]] broken and the kingdom returned to something good. She does not particularly care whether she is the one who rules it afterward. She has spent nineteen years as a throne to which other people's decisions were attached and has no strong attachment to the position itself — only to the idea that the position should mean something again, and be held by someone who is actually governing rather than being governed.

She also wants to leave. Not permanently, not as exile — she is not finished with [[Auralis]] — but she has been inside the same set of rooms, in the same role, performing the same performance, for her entire life. The world is large and she has seen one corner of it. The memory of [[Terravelle]] at thirteen — cold, horizontal, a place where things worked differently — has not left her. She has not been permitted to go back. She thinks about it more than she mentions it to anyone.

These two wants are not unrelated. The council manages her movements as carefully as they manage her training. A queen who travels is a queen who develops a picture of the world that the council did not supply.

## Public Role

At galas, diplomatic events, and formal occasions Cassia is exactly what a queen should be — composed, certain, magnetic in the way of someone who has been performing this role since childhood. She is good at it. The performance is so practiced it no longer feels like performance, which is its own kind of loss.

She attended a trade gala in [[Terravelle]] when she was thirteen, part of a diplomatic delegation managed entirely by council representatives. She remembers very little about the political substance of the visit. She was thirteen and it was her first time north of [[Equatorial Desert|Desert Zakros]] and everything was horizontal and cold and strange.

She is aware that [[Eddan Voss|King Eddan]] has a son. She knows his name. She has not thought about him particularly.

## Relationship with Terravelle

Cassia's personal feelings about [[Terravelle]] are more complicated than the council's. She does not share their certainty that Auralis's expansion is inevitable or righteous. She understands [[Eddan Voss|Eddan's]] position well enough to respect it, which is not something she has ever said out loud in council chambers.

The slow fraying of the peace between the two kingdoms is something she watches with unease she cannot express and influence she cannot exercise. The conditions for open conflict are being met by people acting in her name, with her seal, and she is not sure what she would do about it even if she could.

She hopes, in the quiet way of people who have learned not to hope loudly, that it does not come to war in her lifetime. She does not have a good reason to believe it won't.

*See also: [[Auralis]], [[Eddan Voss]], [[Cael]], [[Drest]], [[The Council of Auralis]], [[Council Members]], [[Maren Sollis]], [[Tovan Ashce]], [[Hadren Cosse]], [[Kingdoms]], [[Flux]], [[Control Tier]], [[Solhaven]]*
