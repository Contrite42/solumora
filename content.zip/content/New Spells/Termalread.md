Takes a full thermal scan of a body or object within short range, returning a detailed map of internal temperature variation.

| Variable | Value |
|---|---|
| Shape | Pentagon |
| Hook | Sense |
| Mode | Create |
| Control Tier | T3 |
| Discipline | Heat |
| Output | Thermal |
| Pattern | Point |
| Reach | Short |
| Persistence | *(default — Immediate)* |
| Target | Individual |

**Rarity:** Uncommon
**Grimoire:** [[Uncommon Grimoire]]
